#!/system/bin/sh

# Service controller script

resetprop -p --delete debug.media.video.frc
resetprop -p --delete debug.media.video.vpp
resetprop -p --delete debug.media.video.aie
resetprop -p --delete debug.media.video.ais
resetprop -p --delete debug.media.video.style
resetprop -p --delete debug.media.video.ace
resetprop -p --delete debug.media.video.meeting

resetprop -p --delete persist.vendor.radio.diag_log_trriger

settings put global dropbox_max_files 5
settings put global hidden_api_policy 0
settings put global hidden_api_policy_p_apps 0
settings put global hidden_api_policy_pre_p_apps 0
settings put global hidden_api_blacklist_exe 0
settings put global netstats_enabled 0
settings put global network_recommendations_enabled 0
settings put global satellite_mode_enabled 1
settings put global settings_network_and_internet_v2 true
settings put system lab_options_visible 1
settings put system cloud_dns_happy_eyeballs_priority_enabled off
settings put system cloud_mtk_wifi_traffic_priority_mode off
settings put system cloud_network_priority_enabled off
settings put system display_yellowpage_tab 0
settings put system miui_recents_show_recommend 0
settings put system oneplus_lab_feature_key 1

resetprop -p --delete ro.telephony.default_network

stop diag_mdlog_auto_start
stop tombstoned
rm -rf /data/anr
rm -rf /data/tombstones
rm -rf /data/*/tombstones
