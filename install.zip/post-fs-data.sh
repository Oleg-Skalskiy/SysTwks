#!/system/bin/sh

# Post Fs controller script
