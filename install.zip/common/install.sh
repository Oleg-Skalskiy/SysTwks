
#QCVIRTJ="$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "qvirtmgr.json")"
DEVF="$(find /system/etc/device_features /vendor/etc/device_features /system_ext/etc/device_features /product/etc/device_features /odm/etc/device_features /my_product/etc/device_features /mi_ext/etc/device_features -type f -name "*.xml")"
MEDPF="$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "media_profiles*.xml")"
ATRACE="$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "atrace.rc")"
DUMPST="$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "*dumpstate*.rc")"
TSTONE="$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "tombstoned.rc")"
PERFETTO="$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "perfetto.rc")"
INITEXT="$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "init.*.ext.rc")"
INITD="$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "init.rc")"
OFFLOG="$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "init.offline.log.rc") | $(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "init.qseelogd.rc") | $(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "init.qti.bt.logger.rc") | $(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "*nativedebug.rc") | $(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "*qsguard.rc") | $(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "*misight.rc") | $(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "*miteelog.rc")"

mkdir -p $MODPATH/tools
cp -f $MODPATH/common/addon/External-Tools/tools/$ARCH32/* $MODPATH/tools/


mkdir -p $MODPATH/system/bin
touch $MODPATH/system/bin/bootlog.sh


if $KSU || [ "$(echo $MAGISK_VER | awk -F- '{ print $NF}')" == "delta" ] || [ "$(echo $MAGISK_VER | awk -F- '{ print $NF}')" == "kitsune" ]; then
rm -rf $MODPATH/post-fs-data.sh
rm -rf $MODPATH/system/my_product
rm -rf $MODPATH/system/vendor/odm
fi


ui_print "*          ->[Preparing! Please Wait!]<-          *"
ui_print "***************************************************"
ui_print "***************************************************"


  for OATRACE in ${ATRACE}; do
	ATRAC="$MODPATH$(echo $OATRACE | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$OATRACE $ATRAC
	sed -i 's/\t/  /g' $ATRAC
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $ATRAC
	done

  for ODUMPST in ${DUMPST}; do
	DUMPS="$MODPATH$(echo $DUMPST | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$ODUMPST $DUMPS
	sed -i 's/\t/  /g' $DUMPS
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $DUMPS
	done

  for OTSTONE in ${TSTONE}; do
	TSTON="$MODPATH$(echo $OTSTONE | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$OTSTONE $TSTON
	sed -i 's/\t/  /g' $TSTON
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $TSTON
	done

  for OINITEXT in ${INITEXT}; do
	INITEX="$MODPATH$(echo $OINITEXT | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$OINITEXT $INITEX
	sed -i 's/\t/  /g' $INITEX
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $INITEX
	done

  for OINITD in ${INITD}; do
	INIT="$MODPATH$(echo $OINITD | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$OINITD $INIT
	sed -i 's/\t/  /g' $INIT
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $INIT
	done

  for OPERFETTO in ${PERFETTO}; do
	PERFETT="$MODPATH$(echo $OPERFETTO | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$OPERFETTO $PERFETT
	sed -i 's/\t/  /g' $PERFETT
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $PERFETT
	done

  for OOFFLOG in ${OFFLOG}; do
	OFFLO="$MODPATH$(echo $OOFFLOG | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$OOFFLOG $OFFLO
	sed -i 's/\t/  /g' $OFFLO
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $OFFLO
	done

#  for OQCVIRT in ${QCVIRTJ}; do
#	QCVIRT="$MODPATH$(echo $OQCVIRT | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
#	cp_ch $ORIGDIR$OQCVIRT $QCVIRT
#	sed -i 's/\t/  /g' $QCVIRT
#	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $QCVIRT
#	done

  for OMEDPF in ${MEDPF}; do
	MEDPFX="$MODPATH$(echo $OMEDPF | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$OMEDPF $MEDPFX
	sed -i 's/\t/  /g' $MEDPFX
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $MEDPFX
	done

  for ODEVF in ${DEVF}; do
	AODEVF="$MODPATH$(echo $ODEVF | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$ODEVF $AODEVF
	sed -i 's/\t/  /g' $AODEVF
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $AODEVF
	done


ui_print "*Including Tweaks: Modem, Camera, Display, Log-OFF*"
ui_print "**  MIUI/HyperOS, Power, System Perfomance & Etc  *"
ui_print "***************************************************"
ui_print "***************************************************"
ui_print "*          ->[Installing Other Tweaks]<-          *"
ui_print "***************************************************"
ui_print "***************************************************"
ui_print " "

#  for OQCVIRT in ${QCVIRTJ}; do
#	QCVIRT="$MODPATH$(echo $OQCVIRT | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
#	sed -i 's/"enable"        : true/"enable"        : false/g' $QCVIRT
#	done

  for OATRACE in ${ATRACE}; do
	ATRAC="$MODPATH$(echo $OATRACE | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	# sed -i 's/sched_schedstats 1/sched_schedstats 0/g' $ATRAC
	sed -i '/debug.atrace.tags.enableflags/d' $ATRAC
	sed -i '/persist.traced.enable/d' $ATRAC
	sed -i 's/enable 1/enable 0/g' $ATRAC
	sed -i 's/tracing_on 1/tracing_on 0/g' $ATRAC
	sed -i '/ro.boot.fastboot.boottrace/a\
	setprop debug.atrace.tags.enableflags 0\
	setprop persist.traced.enable 1' $ATRAC
	sed -i '/filemap/d' $ATRAC
	sed -i '/rss_stat/d' $ATRAC
	sed -i '/^ *#/d; /^ *$/d' $ATRAC
	done

  for ODUMPST in ${DUMPST}; do
	DUMPS="$MODPATH$(echo $DUMPST | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i '/ /d' $DUMPS
	sed -i '/^ *#/d; /^ *$/d' $DUMPS
	done

  for OTSTONE in ${TSTONE}; do
	TSTON="$MODPATH$(echo $OTSTONE | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i '/socket/d' $TSTON
	sed -i '/group/a\
	stop tombstoned\
	disabled\
	stop tombstoned' $TSTON
	sed -i '/^ *#/d; /^ *$/d' $TSTON
	done

  for OINITEXT in ${INITEXT}; do
	INITEX="$MODPATH$(echo $OINITEXT | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$OINITEXT $INITEX
	sed -i '/ims/d' $INITEX
	sed -i '/logd/d' $INITEX
	sed -i '/miuilog/d' $INITEX
	sed -i 's/persist.debug.dalvik.vm.jdwp.enabled 1/persist.debug.dalvik.vm.jdwp.enabled 0/g' $INITEX
	sed -i '/^ *#/d; /^ *$/d' $INITEX
	done

  for OINITD in ${INITD}; do
	INIT="$MODPATH$(echo $OINITD | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i '/tombstone/d' $INIT
	sed -i '/anr/d' $INIT
	sed -i '/filemap/d' $INIT
	sed -i '/rss_stat/d' $INIT
	sed -i '/^ *#/d; /^ *$/d' $INIT
	done

  for OPERFETTO in ${PERFETTO}; do
	PERFETT="$MODPATH$(echo $OPERFETTO | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i '/ /d' $PERFETT
	sed -i '/^ *#/d; /^ *$/d' $PERFETT
	done

  for OOFFLOG in ${OFFLOG}; do
	OFFLO="$MODPATH$(echo $OOFFLOG | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i '/ /d' $OFFLO
	sed -i '/^ *#/d; /^ *$/d' $OFFLO
	done

  for OMEDPF in ${MEDPF}; do
	MEDPFX="$MODPATH$(echo $OMEDPF | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$OMEDPF $MEDPFX
	sed -i 's/ImageEncoding quality (90|80|70|60|50|40)/ImageEncoding quality (100)/g' $MEDPFX
	sed -i 's/ImageEncoding quality="95"/ImageEncoding quality="100"/g' $MEDPFX
	sed -i 's/ImageEncoding quality="90"/ImageEncoding quality="100"/g' $MEDPFX
	sed -i 's/ImageEncoding quality="85"/ImageEncoding quality="100"/g' $MEDPFX
	sed -i 's/ImageEncoding quality="80"/ImageEncoding quality="100"/g' $MEDPFX
	sed -i 's/ImageEncoding quality="75"/ImageEncoding quality="100"/g' $MEDPFX
	sed -i 's/ImageEncoding quality="70"/ImageEncoding quality="100"/g' $MEDPFX
	sed -i 's/ImageDecoding memCap="8000000"/ImageDecoding memCap="30000000"/g' $MEDPFX
	sed -i 's/ImageDecoding memCap="10000000"/ImageDecoding memCap="30000000"/g' $MEDPFX
	sed -i 's/ImageDecoding memCap="20000000"/ImageDecoding memCap="30000000"/g' $MEDPFX
	sed -i '/ATTLIST ImageEncoding/a\
<!ATTLIST ImageDecoding quality (100) #REQUIRED>' $MEDPFX
	sed -i '/ImageEncoding quality=/a\
		<ImageDecoding quality="100" />' $MEDPFX
	sed -i '/^ *#/d; /^ *$/d' $MEDPFX
	done

  for ODEVF in ${DEVF}; do
	AODEVF="$MODPATH$(echo $ODEVF | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
# Sound Start
	sed -i 's/name="btdebug_enabled">true</name="btdebug_enabled">false</g' $AODEVF
	sed -i 's/name="support_ble_oobhelper">false</name="support_ble_oobhelper">true</g' $AODEVF
	sed -i 's/name="support_record_param">false</name="support_record_param">true</g' $AODEVF
	sed -i 's/name="support_interview_record_param">false</name="support_interview_record_param">true</g' $AODEVF
	sed -i 's/name="support_hd_record_param">false</name="support_hd_record_param">true</g' $AODEVF
	sed -i 's/name="support_voip_record">false</name="support_voip_record">true</g' $AODEVF
	sed -i 's/name="support_dolby">false</name="support_dolby">true</g' $AODEVF
	sed -i 's/name="support_hifi">true</name="support_hifi">false</g' $AODEVF
	sed -i 's/name="support_lhdc">false</name="support_lhdc">true</g' $AODEVF
	sed -i 's/name="support_lhdc_offload">false</name="support_lhdc_offload">true</g' $AODEVF
	sed -i 's/name="support_a2dp_latency">false</name="support_a2dp_latency">true</g' $AODEVF
	sed -i 's/name="support_sound_assist">true</name="support_sound_assist">false</g' $AODEVF
	sed -i 's/name="support_new_silentmode">false</name="support_new_silentmode">true</g' $AODEVF
	sed -i 's/name="support_24bit_record">false</name="support_24bit_record">true</g' $AODEVF
	sed -i 's/name="support_audio_loopback">false</name="support_audio_loopback">true</g' $AODEVF
	sed -i 's/name="support_adv_audio_unicast">false</name="support_adv_audio_unicast">true</g' $AODEVF
	sed -i 's/name="support_adv_audio_bca">false</name="support_adv_audio_bca">true</g' $AODEVF
	sed -i 's/name="support_adv_audio_bcs">false</name="support_adv_audio_bcs">true</g' $AODEVF
	sed -i 's/name="support_camera_audio_focus">false</name="support_camera_audio_focus">true</g' $AODEVF
	sed -i 's/name="support_audio_share">false</name="support_audio_share">true</g' $AODEVF
	sed -i 's/name="support_adaptive_sampler">true</name="support_adaptive_sampler">false</g' $AODEVF
	sed -i 's/name="support_bluetooth_cloud_data">false</name="support_bluetooth_cloud_data">true</g' $AODEVF
	sed -i '/<features>/a\
	<bool name="support_lhdc">true</bool>\
	<bool name="support_lhdc_offload">true</bool>\
	<bool name="support_voip_record">true</bool>\
	<bool name="support_ble_oobhelper">true</bool>\
	<bool name="support_audio_share">true</bool>\
	<bool name="support_adaptive_sampler">false</bool>\
	<bool name="support_bluetooth_cloud_data">true</bool>\
	<bool name="support_24bit_record">true</bool>' $AODEVF
# Sound END
	sed -i 's/name="is_xiaomi">false</name="is_xiaomi">true</g' $AODEVF
	sed -i 's/name="is_xiaomi_device">false</name="is_xiaomi_device">true</g' $AODEVF
	sed -i 's/name="support_my_device">false</name="support_my_device">true</g' $AODEVF
	sed -i 's/name="support_erase_external_storage">false</name="support_erase_external_storage">true</g' $AODEVF
	sed -i 's/name="support_hide_discoverable">true</name="support_hide_discoverable">false</g' $AODEVF
	sed -i 's/name="support_agps">false</name="support_agps">true</g' $AODEVF
	sed -i 's/name="support_agps_paras">false</name="support_agps_paras">true</g' $AODEVF
	sed -i 's/name="support_agps_roaming">false</name="support_agps_roaming">true</g' $AODEVF
	sed -i 's/name="support_wifi_low_latency_mode">false</name="support_wifi_low_latency_mode">true</g' $AODEVF
	sed -i 's/name="support_network_rps_mode">false</name="support_network_rps_mode">true</g' $AODEVF
	sed -i 's/name="support_camera_peaking_mf">false</name="support_camera_peaking_mf">true</g' $AODEVF
	sed -i 's/name="support_camera_4k_quality">false</name="support_camera_4k_quality">true</g' $AODEVF
	sed -i 's/name="support_camera_8k_quality">false</name="support_camera_8k_quality">true</g' $AODEVF
	sed -i 's/name="support_zoom_mfnr">false</name="support_zoom_mfnr">true</g' $AODEVF
	sed -i 's/name="support_mfnr">false</name="support_mfnr">true</g' $AODEVF
	sed -i 's/name="support_camera_mfnr">false</name="support_camera_mfnr">true</g' $AODEVF
	sed -i 's/name="support_front_beauty_mfnr">false</name="support_front_beauty_mfnr">true</g' $AODEVF
	sed -i 's/name="support_video_hfr_mode">false</name="support_video_hfr_mode">true</g' $AODEVF
#	sed -i 's/name="support_chroma_flash">false</name="support_chroma_flash">true</g' $AODEVF
	sed -i 's/name="support_object_track">false</name="support_object_track">true</g' $AODEVF
	sed -i 's/name="is_camera_hide_hht_menu">true</name="is_camera_hide_hht_menu">false</g' $AODEVF
	sed -i 's/name="is_camera_replace_higher_cost_effect">false</name="is_camera_replace_higher_cost_effect">true</g' $AODEVF
	sed -i 's/name="support_psensor_pocket_mode">false</name="support_psensor_pocket_mode">true</g' $AODEVF
	sed -i 's/name="camera_adjust_picture_size_enabled">true</name="camera_adjust_picture_size_enabled">false</g' $AODEVF
	sed -i 's/name="support_display_expert_mode">false</name="support_display_expert_mode">true</g' $AODEVF
	sed -i 's/name="support_screen_enhance_engine">false</name="support_screen_enhance_engine">true</g' $AODEVF
	sed -i 's/name="support_true_color">false</name="support_true_color">true</g' $AODEVF
	sed -i 's/name="support_videobox_display_effect">false</name="support_videobox_display_effect">true</g' $AODEVF
	sed -i 's/name="is_support_video_tool_box">false</name="is_support_video_tool_box">true</g' $AODEVF
	sed -i 's/name="support_displayfeature_gamemode">false</name="support_displayfeature_gamemode">true</g' $AODEVF
	sed -i 's/name="support_secret_dc_backlight">false</name="support_secret_dc_backlight">true</g' $AODEVF
	sed -i 's/name="hide_flicker_backlight">true</name="hide_flicker_backlight">false</g' $AODEVF
	sed -i 's/name="support_AI_display">false</name="support_AI_display">true</g' $AODEVF
	sed -i 's/name="support_nature_mode">true</name="support_nature_mode">false</g' $AODEVF
	sed -i 's/name="support_truetone">false</name="support_truetone">true</g' $AODEVF
	sed -i 's/name="support_power_mode">false</name="support_power_mode">true</g' $AODEVF
	sed -i 's/name="support_gallery_hdr">false</name="support_gallery_hdr">true</g' $AODEVF
	sed -i 's/name="support_hdr_enhance">false</name="support_hdr_enhance">true</g' $AODEVF
	sed -i 's/name="gallery_support_media_feature">false</name="gallery_support_media_feature">true</g' $AODEVF
	sed -i 's/name="gallery_support_video_compress">false</name="gallery_support_video_compress">true</g' $AODEVF
	sed -i 's/name="gallery_support_analytic_face_and_scene">false</name="gallery_support_analytic_face_and_scene">true</g' $AODEVF
	sed -i 's/name="gallery_support_time_burst_video">false</name="gallery_support_time_burst_video">true</g' $AODEVF
	sed -i 's/name="gallery_support_dolby">false</name="gallery_support_dolby">true</g' $AODEVF
	sed -i 's/name="support_manual_dimming">false</name="support_manual_dimming">true</g' $AODEVF
	sed -i 's/name="gallery_support_print">false</name="gallery_support_print">true</g' $AODEVF
	sed -i 's/name="optimize_wakelock_enabled">false</name="optimize_wakelock_enabled">true</g' $AODEVF
	sed -i 's/name="support_super_resolution">false</name="support_super_resolution">true</g' $AODEVF
	sed -i 's/name="support_ultra_resolution">false</name="support_ultra_resolution">true</g' $AODEVF
	sed -i 's/name="is_full_size_effect">false</name="is_full_size_effect">true</g' $AODEVF
	sed -i 's/name="support_full_size_panorama">false</name="support_full_size_panorama">true</g' $AODEVF
	sed -i 's/name="is_lower_size_effect">true</name="is_lower_size_effect">false</g' $AODEVF
	sed -i 's/name="is_lower_size_panorama">true</name="is_lower_size_panorama">false</g' $AODEVF
	sed -i 's/name="is_video_screen">false</name="is_video_screen">true</g' $AODEVF
	sed -i 's/name="support_low_brightness_fod">false</name="support_low_brightness_fod">true</g' $AODEVF
	sed -i 's/name="support_power_save_new">false</name="support_power_save_new">true</g' $AODEVF
	sed -i 's/name="support_videobox_cinema_adapt_ce">false</name="support_videobox_cinema_adapt_ce">true</g' $AODEVF
	sed -i 's/name="support_camera_satellite">false</name="support_camera_satellite">true</g' $AODEVF
	sed -i 's/name="support_power_consumption">false</name="support_power_consumption">true</g' $AODEVF
	sed -i 's/name="support_edgesuppression_with_sensor">false</name="support_edgesuppression_with_sensor">true</g' $AODEVF
	sed -i '/<features>/a\
	<bool name="is_video_screen">true</bool>\
	<bool name="support_power_consumption">true</bool>\
	<bool name="support_AI_display">true</bool>\
	<bool name="support_screen_enhance_engine">true</bool>\
	<bool name="support_zoom_mfnr">true</bool>\
	<bool name="support_mfnr">true</bool>\
	<bool name="support_camera_mfnr">true</bool>\
	<bool name="support_camera_4k_quality">true</bool>\
	<bool name="support_camera_8k_quality">true</bool>\
	<bool name="support_gallery_hdr">true</bool>\
	<bool name="support_hdr_enhance">true</bool>\
	<bool name="gallery_support_media_feature">true</bool>\
	<bool name="gallery_support_video_compress">true</bool>\
	<bool name="gallery_support_analytic_face_and_scene">true</bool>\
	<bool name="gallery_support_time_burst_video">true</bool>\
	<bool name="gallery_support_dolby">true</bool>\
	<bool name="gallery_support_print">true</bool>\
	<bool name="support_manual_dimming">true</bool>\
	<bool name="optimize_wakelock_enabled">true</bool>\
	<bool name="support_super_resolution">true</bool>\
	<bool name="support_ultra_resolution">true</bool>\
	<bool name="is_full_size_effect">true</bool>\
	<bool name="is_lower_size_effect">false</bool>\
	<bool name="support_full_size_panorama">true</bool>\
	<bool name="is_lower_size_panorama">false</bool>\
	<bool name="support_power_save_new">true</bool>\
	<bool name="support_videobox_cinema_adapt_ce">true</bool>\
	<bool name="support_camera_satellite">true</bool>\
	<bool name="is_camera_hide_hht_menu">false</bool>' $AODEVF
	sed -i '/sar_/d' $AODEVF
	sed -i '/_sar/d' $AODEVF
	sed -i '/^ *#/d; /^ *$/d' $AODEVF
	done

	settings put global dropbox_max_files 5
	settings put global hidden_api_policy 0
	settings put global hidden_api_policy_p_apps 0
	settings put global hidden_api_policy_pre_p_apps 0
	settings put global hidden_api_blacklist_exe 0
	settings put global netstats_enabled 0
	settings put global network_recommendations_enabled 0
	settings put global satellite_mode_enabled 1
	settings put global settings_network_and_internet_v2 true
	settings put system lab_options_visible 1
	settings put system cloud_dns_happy_eyeballs_priority_enabled off
	settings put system cloud_mtk_wifi_traffic_priority_mode off
	settings put system cloud_network_priority_enabled off
	settings put system display_yellowpage_tab 0
	settings put system miui_recents_show_recommend 0
	settings put system oneplus_lab_feature_key 1


	rm -rf $MODPATH/tools
	rm -rf /data/system/package_cache/*/*
	rm -rf /data/resource-cache/*
	rm -rf /cache/*
	rm -rf /data/local/traces
	rm -rf /data/*/*battery*
	rm -rf /data/*/*charge*
	rm -rf /data/*/bsplog
	rm -rf /data/anr
	rm -rf /data/tombstones
	rm -rf /data/*/tombstones
	find $MODPATH -empty -type d -delete
