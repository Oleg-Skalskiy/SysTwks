### SysTwks v1.1 - 01.07.2024

* In item Other
  * Cut from AIST module as a separate module for system tweaks
  * Improved system smoothness
  * New Camera Parametrs
  * Fix photo quality (no compress)
  * MGLRU is Enable (Core mode)
  * New Systems Parametrs
  * Removed waste parameters
  * Updated Radio(Modem) Parametrs
  * Fixed excessive battery consumption
  * Added new options for MIUI
  * Atrace, Tombstoned, DumpState, Log, etc are Disabled
  * Perfetto & IORap is OFF
  * FIX OFF Logging
  * Minor edits
* General
  * Fix Code
  * Fix Some Error
  * Fix Stability System
  * Minor edits
  * Updated base module file MMT (Thanks Zackptg5)
